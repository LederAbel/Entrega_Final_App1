from setuptools import setup

setup (name="Segunda_pre_entrega_LEDER",version="1.0",
       description="Es un paquete para generar usuarios y clientes en una página de compras online",
       author="Abel Leder",author_email="abelleder@gmail.com")